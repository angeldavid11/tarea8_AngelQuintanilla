const config = {
    WIDTH_CANVAS: 400, //reescalamos la imagen en el canvas para optimizar el rendimiento
    GRID_SIZE: 3,
    STEP_SIZE: Math.floor(256 / 3),
};

export default config;